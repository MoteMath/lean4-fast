"""Replay failed master builds on an explicitly different upstream nightly corpus."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

from rerun_builds import command, downstream_real, modules, read, recipe, sha, write


REPO = "https://github.com/leanprover/downstream-lean4.git"
PIN = "308730c4b2152d7235458fde7dcd22eda85bbf3b"
MASTER = "bed19d08b0bc23410437bd46b3dade3b3a8fd56e"
PRE_CORRECTION = "4fa92d632b6d2b51460c643a9aea8244564f85b6"
PACKAGES = {"qq": "quote4", "import_graph": "import-graph", "doc_gen4": "doc-gen4",
            "aesop": "aesop", "plausible": "plausible", "batteries": "batteries",
            "real_basic": "mathlib4", "full_mathlib": "mathlib4", "downstream_real": "mathlib4"}


def fetch(path):
    if not (path / ".git").is_dir():
        path.mkdir(parents=True, exist_ok=True)
        subprocess.run(["git", "init", "-q", path], check=True)
    if subprocess.run(["git", "-C", path, "cat-file", "-e", PIN], capture_output=True).returncode:
        subprocess.run(["git", "-C", path, "fetch", "--depth=1", REPO, PIN], check=True)
    subprocess.run(["git", "-C", path, "checkout", "--detach", "-q", PIN], check=True)
    if command(["git", "-C", path, "status", "--porcelain"]):
        raise ValueError(f"dirty nightly source tree: {path}")


def materialize(src, dest, pkg):
    # Keep relative paths in the monorepo's committed package-overrides files.
    required = {pkg}
    pending = [pkg]
    while pending:
        parent = src / pending.pop()
        overrides = parent / ".lake/package-overrides.json"
        if overrides.exists():
            for dep in read(overrides)["packages"]:
                name = (parent / dep["dir"]).resolve().relative_to(src).parts[0]
                if name not in required:
                    required.add(name)
                    pending.append(name)
    # Some Lake packages inspect the working tree's Git revision during setup.
    # A shared object store keeps each clean checkout cheap without sharing build outputs.
    subprocess.run(["git", "clone", "-q", "--shared", "--no-checkout", src, dest], check=True)
    subprocess.run(["git", "-C", dest, "sparse-checkout", "set", "--cone", *sorted(required)], check=True)
    subprocess.run(["git", "-C", dest, "checkout", "-q", "--detach", PIN], check=True)


def configure_downstream(project, mathlib):
    downstream_real(project, mathlib)
    # Bootstrap Lake from a complete path manifest. Generating the initial manifest
    # via 'lake update' consults Mathlib's original git dependencies before overrides.
    overrides = read(mathlib / ".lake/package-overrides.json")
    for dep in overrides["packages"]:
        dep["dir"] = str((mathlib / dep["dir"]).resolve())
        dep["inherited"] = True
    packages = [*overrides["packages"], {
        "type": "path", "subDir": None, "scope": "", "name": "mathlib",
        "manifestFile": "lake-manifest.json", "inherited": False,
        "configFile": "lakefile.lean", "dir": str(mathlib.resolve())}]
    write(project / "lake-manifest.json", {
        "version": overrides["version"], "name": "downstream_real", "lakeDir": ".lake",
        "packagesDir": ".lake/packages", "packages": packages, "fixedToolchain": False})


def execute(args, case, env, staging, kept):
    workload = case.split("_p6_")[0]
    row = dict(case=case, workload=workload, commit=args.commit, source_url=REPO,
               source_revision=PIN, corpus_matches_baseline=False,
               status="failed", elapsed_sec=None)
    area = staging / case
    try:
        pkg = PACKAGES[workload]
        if workload == "downstream_real":
            if "real_basic" not in kept:
                raise ValueError("requires successful cold Mathlib.Data.Real.Basic")
            project = area
            mathlib = kept["real_basic"] / "mathlib4"
            configure_downstream(project, mathlib)
        elif workload == "full_mathlib" and "zygote" in case:
            if workload not in kept:
                raise ValueError("requires successful cold Full Mathlib")
            area = kept.pop(workload)
            project = area / pkg
            # The archived zygote recipe preserves built dependencies and clears the root.
            shutil.rmtree(project / ".lake/build")
        else:
            materialize(args.pool, area, pkg)
            project = area / pkg
        original = args.source / "benchmarks/aws_ecosystem_phase6/cpu_c7a_96vcpu" / (case + ".json")
        argv = recipe(read(original), args.bin_dir, args.source, project)
        row.update(source_git_tree=command(["git", "-C", args.pool, "rev-parse", PIN + ":" + pkg]),
                   declared_toolchain=(args.pool / "lean-toolchain").read_text().strip(), command=argv,
                   comparison_note="Different upstream source and dependencies; no paired timing delta.")
        log = args.output / (case + ".build.log")
        metric = args.output / (case + ".measurement.json")
        result = subprocess.run([sys.executable, args.source / "benchmarks/measure_linux_bench.py",
                                 "--workdir", project, "--json-out", metric, "--", "bash", "-c",
                                 'exec "$@" >"$0" 2>&1', log, *argv], env=env, stdout=subprocess.DEVNULL)
        text = log.read_text(errors="replace")
        data = read(metric)
        built = modules(text)
        signature = json.dumps(sorted(built.items()), separators=(",", ":")).encode()
        row.update(log_sha256=sha(log), metrics=data, built_modules=built.total(),
                   built_modules_sha256=hashlib.sha256(signature).hexdigest(),
                   root_oleans=sum(1 for _ in (project / ".lake/build/lib/lean").rglob("*.olean")))
        if "zygote" in case:
            stats = re.findall(r"shutdown stats snapshot_hits=(\d+) clean_cow_hits=(\d+) fallbacks=(\d+)", text)
            row["zygote_stats"] = dict(zip(("snapshot_hits", "clean_cow_hits", "fallbacks"), map(int, stats[-1]))) if stats else None
        if result.returncode or data["exit_code"] or not row["root_oleans"] or not row["built_modules"]:
            row["comparison_note"] = "Supplementary source build failed or produced no new root modules."
        elif "zygote" in case and not row["zygote_stats"]:
            row["comparison_note"] = "Supplementary build lacks zygote service counters."
        else:
            row.update(status="ok", elapsed_sec=data["elapsed_sec"])
            if case in ("real_basic_p6_cold", "full_mathlib_p6_cold"):
                kept[workload] = area
    except (KeyError, ValueError, OSError, subprocess.SubprocessError) as e:
        row["comparison_note"] = str(e)
    finally:
        if area.is_dir() and area not in kept.values():
            shutil.rmtree(area)
    write(args.output / (case + ".rerun.json"), row)
    print(case, row["status"], row["elapsed_sec"], flush=True)
    return row


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("source", "bin-dir", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--pool", type=Path, default=Path("/mnt/work/corpora/master-nightly"))
    p.add_argument("--work", type=Path, default=Path("/mnt/work/supplemental-builds"))
    p.add_argument("--original", type=Path, default=Path("/mnt/work/results/master/summary.json"))
    p.add_argument("--prepare", action="store_true")
    p.add_argument("--cases", nargs="+")
    p.add_argument("--commit", choices=(MASTER, PRE_CORRECTION), default=MASTER)
    args = p.parse_args()
    args.pool = args.pool.resolve()
    fetch(args.pool)
    if args.prepare:
        return 0
    if command(["git", "-C", args.source, "rev-parse", "HEAD"]) != args.commit:
        raise ValueError("master source checkout revision mismatch")
    if command([args.bin_dir / "lean", "--githash"]) != args.commit:
        raise ValueError("master compiler revision mismatch")
    failures = {row["case"] for row in read(args.original) if row["status"] != "ok"}
    # Keep unported cases visible in the original results; avoid invented source matches.
    cases = [c for c in failures if c.split("_p6_")[0] in PACKAGES and "_p6_" in c]
    if args.cases:
        cases = [c for c in cases if c in args.cases]
    if any(c.startswith("downstream_real_") for c in cases) and "real_basic_p6_cold" not in cases:
        cases.append("real_basic_p6_cold")
    if any(c.startswith("full_mathlib_p6_zygote") for c in cases) and "full_mathlib_p6_cold" not in cases:
        cases.append("full_mathlib_p6_cold")
    def priority(c):
        group = c.split("_p6_")[0]
        return (0 if group == "real_basic" else 2 if group == "full_mathlib" else 1, c)
    cases.sort(key=priority)
    args.work.mkdir(parents=True, exist_ok=True)
    args.output.mkdir(parents=True, exist_ok=True)
    if any(args.output.glob("*.rerun.json")):
        p.error("output already contains receipts")
    env = os.environ.copy()
    for key in ("ELAN_TOOLCHAIN", "LAKE_JOBS", "LEAN_NUM_THREADS", "LAKE_CHILD_LEAN_THREADS",
                "LEAN_PATH", "LEAN_SYSROOT"):
        env.pop(key, None)
    env["PATH"] = str(args.bin_dir) + ":" + ":".join(x for x in env["PATH"].split(":") if not x.rstrip("/").endswith(".elan/bin"))
    env["MATHLIB_NO_CACHE_ON_UPDATE"] = "1"
    rows = []
    with tempfile.TemporaryDirectory(prefix="nightly-", dir=args.work) as tmp:
        kept = {}
        for case in cases:
            rows.append(execute(args, case, env, Path(tmp), kept))
            write(args.output / "summary.json", rows)
    return int(any(r["status"] != "ok" for r in rows))


if __name__ == "__main__":
    sys.exit(main())
