"""Compare Phase 6 cache rerun receipts with the original c7a measurements."""

import argparse
from collections import Counter
import hashlib
import json
import math
import re
from statistics import median
import zipfile
from pathlib import Path


TIPS = {
    "v4.35.0-fast": "2b82eb00f8612124e6dface4685f411b7a7df865",
    "master": "bed19d08b0bc23410437bd46b3dade3b3a8fd56e",
}
MASTER_BEFORE = "4fa92d632b6d2b51460c643a9aea8244564f85b6"
FAST_BEFORE = "4f98a0c3eccbe1c92325110145adbf09e96c150b"
NIGHTLY = "308730c4b2152d7235458fde7dcd22eda85bbf3b"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def positive(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def originals(directory):
    cases = {}
    for path in sorted(directory.glob("*_p6_*.json")):
        result = read(path)
        if result["exit_code"] != 0 or not positive(result["elapsed_sec"]):
            raise ValueError(f"Invalid published measurement: {path}")
        cases[path.stem] = (path, "s", result["elapsed_sec"])
    profiles = sorted(directory.glob("synthetic_profile_S*.log")) + [directory / "synthetic_s5_bv_congpu.log"]
    for path in profiles:
        matches = re.findall(r"^\s*elaboration\s+([\d.]+)\s*(ms|s)\s*$", path.read_text(encoding="utf-8-sig"), re.M)
        if len(matches) != 1:
            raise ValueError(f"Expected one cumulative elaboration measurement in {path}")
        value, unit = matches[0]
        cases[path.stem] = (path, "ms", float(value) * (1000 if unit == "s" else 1))
    if len(cases) != 33 or len(profiles) != 7:
        raise ValueError(f"Expected 26 build timings and 7 profiles in {directory}")
    return cases


def branch_results(root, commit, cases, machine):
    host_path = root / "host.json"
    host = read(host_path)
    if host["commit"] != commit or host.get("lean_githash") != commit:
        raise ValueError(f"Wrong checkout or compiler in {host_path}")
    if machine and host.get("instance_type") and host["instance_type"] != machine["instanceType"]:
        raise ValueError(f"Conflicting machine identity in {host_path}")
    instance = machine.get("instanceType", host.get("instance_type"))
    rows = {}
    for case, (original, unit, baseline) in cases.items():
        path = root / f"{case}.rerun.json"
        if not path.is_file():
            rows[case] = {"status": "missing-receipt"}
            continue
        data = read(path)
        if data["case"] != case or data["commit"] != commit:
            raise ValueError(f"Wrong case or source commit in {path}")
        status = data["status"]
        if data["baseline_sha256"] != sha(original):
            raise ValueError(f"Wrong baseline receipt in {path}")
        if data.get("log_sha256"):
            log = root / (case + (".log" if unit == "ms" else ".build.log"))
            if sha(log) != data["log_sha256"]:
                raise ValueError(f"Log hash mismatch in {path}")
        source = data.get("source_revision")
        corpus_matches = data.get("corpus_matches_baseline")
        value = data.get("profile_elaboration_ms" if unit == "ms" else "elapsed_sec")
        row = {
            "status": status, "receipt": path.name, "receipt_sha256": sha(path),
            "source_revision": source, "note": data.get("comparison_note"),
            "corpus_matches": corpus_matches, "built_modules": data.get("built_modules"),
            "baseline_modules_missing": data.get("baseline_modules_missing"),
            "new_modules_added": data.get("new_modules_added"),
        }
        if status == "ok":
            if not positive(value):
                raise ValueError(f"Successful run without positive measurement: {path}")
            if unit == "s" and (data["metrics"]["exit_code"] != 0 or data["built_modules"] < 1 or data["root_oleans"] < 1):
                raise ValueError(f"Build marked successful without compiled module evidence: {path}")
            row["measured"] = value
            baseline_field = "baseline_profile_elaboration_ms" if unit == "ms" else "baseline_seconds"
            if data.get(baseline_field) is not None and not math.isclose(data[baseline_field], baseline, rel_tol=1e-6):
                raise ValueError(f"Conflicting original timing in {path}")
            if corpus_matches is not True:
                row["comparison"] = "source differs or unverified"
            elif unit == "s" and data.get("module_set_matches_baseline") is not True:
                row["comparison"] = "build work differs or unverified"
            elif instance != "c7a.24xlarge":
                row["comparison"] = "different or unverified host"
            else:
                row["comparison"] = "matched"
                row["change_pct"] = round(100 * (value / baseline - 1), 3)
        rows[case] = row
    return {"commit": commit, "instance_type": instance, "toolchain_version": host.get("lean_version"),
            "toolchain_githash": host.get("lean_githash"), "cases": rows}


def format_result(row, unit):
    if row["status"] != "ok":
        return "prerequisite failed" if row["status"] == "missing-input" else row["status"]
    digits = 3 if unit == "s" else 2
    value = f"{row['measured']:.{digits}f}"
    if row["comparison"] == "matched":
        return f"{value} ({row['change_pct']:+.1f}%)"
    if row.get("new_modules_added") and row.get("baseline_modules_missing") == 0:
        return f"{value} ({row['new_modules_added']} extra modules)"
    return f"{value} ({row['comparison']})"


def supplemental(root, groups):
    """Validate additional native measurements and their logs before pairing."""
    results = {}
    for group, commit in groups.items():
        rows = {}
        for path in sorted((root / group).glob("*.rerun.json")):
            data = read(path)
            case = data["case"]
            if data["commit"] != commit or path.name != f"{case}.rerun.json":
                raise ValueError(f"Unexpected supplemental identity in {path}")
            if "compatible" in group and data["source_revision"] != NIGHTLY:
                raise ValueError(f"Unexpected nightly corpus in {path}")
            if data.get("log_sha256") and data["log_sha256"] != sha(path.with_name(case + ".build.log")):
                raise ValueError(f"Bad supplemental log hash in {path}")
            if data["status"] == "ok":
                if (not positive(data.get("elapsed_sec")) or data["metrics"]["exit_code"] != 0
                        or data["root_oleans"] < 1 or data["built_modules"] < 1):
                    raise ValueError(f"Successful supplemental build lacks measured output in {path}")
            rows[case] = data
        results[group] = rows
    return results


def extra_tables(root):
    groups = {"master-compatible": TIPS["master"], "master-compatible-downstream": TIPS["master"], "master-control": MASTER_BEFORE,
              "master-control-compatible": MASTER_BEFORE, "fast-control": FAST_BEFORE}
    extra = supplemental(root, groups)
    lines = []
    pairs = []
    nightly = dict(extra["master-compatible"])
    repaired = []
    for case, retry in extra["master-compatible-downstream"].items():
        if case.startswith("downstream_real_") and retry["status"] == "ok":
            if nightly[case]["status"] == "ok":
                raise ValueError(f"Unexpected success in both nightly DownstreamReal attempts: {case}")
            nightly[case] = retry
            repaired.append(case)
    if nightly:
        lines.extend(["### Master on the newer downstream corpus", "",
                      f"The additional builds used [downstream-lean4 at `{NIGHTLY[:10]}`]"
                      f"(https://github.com/leanprover/downstream-lean4/tree/{NIGHTLY}). "
                      "These times use different source revisions from the published 4.35 inputs.", "",
                      "| Case | Master elapsed (s) | Compiled modules |", "| --- | ---: | ---: |"])
        for case, row in nightly.items():
            value = f"{row['elapsed_sec']:.3f}" if row["status"] == "ok" else row["status"]
            lines.append(f"| `{case}` | {value} | {row.get('built_modules', '—')} |")
        lines.append("")
        if repaired:
            lines.extend(["The initial DownstreamReal package manifest resolved incompatible dependencies. "
                          "The reported successful retries used a complete local manifest for the same "
                          "pinned source. The archive preserves both attempts and the Real.Basic preparation "
                          "run used by the retry.", ""])
        lines.extend(["Cedar’s published project targets 4.35.0 and failed on master. "
                      "The downstream nightly corpus contains no Cedar port.", ""])
    for group in ("fast-control", "master-control", "master-control-compatible"):
        for case, before in extra[group].items():
            compatible = group.endswith("compatible")
            branch = "fast" if group == "fast-control" else "master"
            if compatible:
                after = nightly.get(case)
                same = bool(after and before.get("source_git_tree") and before.get("source_git_tree") == after.get("source_git_tree")
                            and before.get("built_modules_sha256") and before.get("built_modules_sha256") == after.get("built_modules_sha256"))
            else:
                after = read(root / branch / (case + ".rerun.json"))
                def built(label):
                    path = root / label / (case + ".build.log")
                    if not path.is_file():
                        return Counter()
                    return Counter(re.findall(r"\[\d+/\d+\] Built ([\w.']+)(?= \(|$)", path.read_text(encoding="utf-8", errors="replace"), re.M))
                old_modules = built(group)
                same = bool(before.get("corpus_matches_baseline") and after.get("corpus_matches_baseline")
                            and old_modules and old_modules == built(branch))
            row = {"case": case, "branch": "v4.35.0-fast" if branch == "fast" else "master",
                   "corpus": "downstream nightly" if compatible else "Phase 6",
                   "before_sec": before.get("elapsed_sec"), "after_sec": after.get("elapsed_sec") if after else None}
            if same and before["status"] == "ok" and after["status"] == "ok":
                row["change_pct"] = round(100 * (row["after_sec"] / row["before_sec"] - 1), 3)
            pairs.append(row)
    if pairs:
        lines.extend(["### Before and after the correction on c7a", "",
                      f"One paired run compares each green compiler with its own pre-correction build, "
                      f"`{FAST_BEFORE[:10]}` on fast and `{MASTER_BEFORE[:10]}` on master. "
                      "Percentages require matching source and compiled module sets.", "",
                      "| Branch | Corpus | Case | Before (s) | After (s) | Change |", "| --- | --- | --- | ---: | ---: | ---: |"])
        for row in pairs:
            fields = [f"{row[k]:.3f}" if row[k] is not None else "—" for k in ["before_sec", "after_sec"]]
            change = f"{row['change_pct']:+.2f}%" if "change_pct" in row else "—"
            lines.append(f"| `{row['branch']}` | {row['corpus']} | `{row['case']}` | {fields[0]} | {fields[1]} | {change} |")
        lines.append("")
    return lines, pairs, extra


def bundle(path, files):
    with zipfile.ZipFile(path, "w") as archive:
        for name, content in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            archive.writestr(entry, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def wsl_controls(path):
    data = read(path)
    tools = data["metadata"]["toolchains"]
    lines = ["### Paired builds on WSL", "",
             "On a shared Ryzen 7 3700X host, each compiler used four Lake jobs and one Lean thread "
             "per child. Each workload had a warm-up followed by four before/after pairs with "
             "alternating order. The table reports medians in seconds and the range of paired changes.", "",
             "| Branch | Workload | Before | After | Change of medians | Paired range |",
             "| --- | --- | ---: | ---: | ---: | ---: |"]
    if len(data["observations"]) != 40 or any(row["exit"] != 0 or not row["equal_to_expected_modules"] for row in data["observations"]):
        raise ValueError("Incomplete WSL measurements or unequal compiled modules")
    for row in data["summary"]:
        branch, workload = row["branch"], row["workload"]
        tag = "master" if branch == "master" else "fast"
        if tools[tag + "-after"]["git_sha"] != TIPS[branch]:
            raise ValueError(f"Incorrect WSL compiler for {branch}")
        sides = []
        for side in ["before", "after"]:
            runs = sorted((x for x in data["observations"] if x["tool"] == tag + "-" + side
                          and x["workload"] == workload and x["repetition"] != 0), key=lambda x: x["repetition"])
            if [x["repetition"] for x in runs] != [1, 2, 3, 4]:
                raise ValueError(f"Incomplete WSL pair for {tag} {workload}")
            sides.append([x["elapsed_ns"] / 1e9 for x in runs])
        before, after = map(median, sides)
        delta = 100 * (after / before - 1)
        paired = [100 * (a / b - 1) for b, a in zip(*sides)]
        if abs(row["percent_change_of_medians"] - delta) > 0.001:
            raise ValueError(f"WSL median mismatch for {tag} {workload}")
        lines.append(f"| `{branch}` | {workload} | {before:.3f} | {after:.3f} | {delta:+.1f}% | "
                     f"{min(paired):+.1f}% to {max(paired):+.1f}% |")
    lines.extend(["", "All four ranges contain both increases and decreases.", ""])
    return lines


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ["baseline", "fast", "master", "out"]:
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--cloud", type=Path, help="EC2 instance identity document shared by both benchmark runs")
    parser.add_argument("--recipes", type=Path, help="Directory containing rerun_builds.py, master_compatible.py and cloud_inputs.py")
    args = parser.parse_args()
    cases = originals(args.baseline)
    machine = read(args.cloud) if args.cloud else {}
    branches = {name: branch_results(root, TIPS[name], cases, machine)
                for name, root in zip(TIPS, [args.fast, args.master])}
    extra_lines, pairs, extra = extra_tables(args.master.parent)
    safe_cloud = {k:machine[k] for k in ["imageId", "instanceType", "region", "availabilityZone", "pendingTime", "architecture"] if k in machine}
    evidence = {
        "baseline_instance": "c7a.24xlarge",
        "cloud": safe_cloud,
        "baseline": {case: {"receipt": p.name, "receipt_sha256": sha(p), "unit": u, "value": b}
                     for case, (p, u, b) in cases.items()},
        "branches": branches, "native_pairs": pairs,
        "supplemental_attempts": {
            group: {case: {"status": row["status"], "elapsed_sec": row.get("elapsed_sec"),
                           "receipt": f"{group}/{case}.rerun.json",
                           "receipt_sha256": sha(args.master.parent / group / (case + ".rerun.json"))}
                    for case, row in rows.items()} for group, rows in extra.items() if rows},
    }
    lines = [
        "# Phase 6 cache correction benchmarks", "",
        "The published baseline used Stage 2 Lean 4.35.0 on a c7a.24xlarge with 96 vCPUs. "
        "Build values are elapsed seconds. Profile values are milliseconds in the Lean profiler’s "
        "cumulative elaboration counter. The first two tables compare with those published results. "
        "The paired controls below compare builds before and after the cache correction within each "
        "compiler branch.", "",
    ]
    for name, branch in branches.items():
        counts = Counter(row["status"] for row in branch["cases"].values())
        labels = {"ok": "successful", "missing-input": "blocked by prerequisites"}
        count_text = ", ".join(f"{n} {labels.get(status, status)}" for status, n in sorted(counts.items()))
        host = branch["instance_type"] or "unverified instance"
        lines.append(f"- `{name}` at `{branch['commit'][:10]}` on {host} recorded {count_text} out of {len(cases)} cases.")
    lines.extend(["", "Percentages give the elapsed-time change from the published baseline for matching inputs, "
                  "build work and instance type. Negative values indicate a shorter run. "
                  "The cloud runs used native Stage 2 builds at each green commit, matching the "
                  "original build configuration. The master comparison includes the compiler "
                  "version change to 4.37.0-pre. Each historical comparison uses one run per cell. "
                  "Cold builds started with fresh root Lake outputs. The run order differed from the "
                  "original suite, and OS page-cache state was uncontrolled.", ""])
    for unit, title in [("s", "Lake builds (seconds)"), ("ms", "Synthetic elaboration profiles (milliseconds)")]:
        lines.extend([f"### {title}", "", "| Published case | Phase 6 | v4.35.0-fast | master |",
                      "| --- | ---: | ---: | ---: |"])
        for case, (_, row_unit, value) in cases.items():
            if unit != row_unit:
                continue
            fast, master = [format_result(item["cases"][case], unit) for item in branches.values()]
            lines.append(f"| `{case}` | {value:g} | {fast} | {master} |")
        lines.append("")
        if unit == "s" and branches["master"]["cases"]["full_mathlib_p6_cold"]["status"] == "failed":
            lines.extend(["On master, the published Lean 4.35 sources encounter compiler and API "
                          "changes. For example, pinned Batteries and ImportGraph use the removed "
                          "`Lean.Environment.const2ModIdx` field. The failed Full Mathlib and "
                          "Mathlib.Data.Real.Basic cold builds left three dependent measurements "
                          "without their required inputs.", ""])
        if unit == "s":
            ds = [branches["v4.35.0-fast"]["cases"][f"downstream_real_p6_{mode}"] for mode in ["cold", "zygote"]]
            if all(row.get("new_modules_added") == 275 and row.get("baseline_modules_missing") == 0 for row in ds):
                lines.extend(["Both fast DownstreamReal runs compiled 275 additional modules. Their "
                              "wall times are shown without a percentage because the amount of "
                              "compiled work changed.", ""])
    lines.extend(extra_lines)
    local = args.master.parent / "wsl_matched_cache_controls.json"
    if local.exists():
        lines.extend(wsl_controls(local))
    lines.extend(["The evidence archive contains the measured receipts and their build or profiler logs. "
                  "[Comparison data](comparison.json) · [Benchmark evidence](evidence.zip)", "",
                  "To inspect the local paired timings after extracting the archive, run "
                  "`jq '.summary[] | {branch, workload, before_median_seconds, after_median_seconds, "
                  "paired_percent_change_range}' wsl_matched_cache_controls.json`.", ""])
    args.out.mkdir(parents=True, exist_ok=True)
    public = {"machine.json": json.dumps(safe_cloud, indent=2).encode()}
    script_dir = Path(__file__).resolve().parent
    recipes = args.recipes or (script_dir if (script_dir / "rerun_builds.py").exists() else script_dir.parent)
    for name in ("rerun_builds.py", "master_compatible.py", "cloud_inputs.py"):
        public["recipes/" + name] = (recipes / name).read_bytes()
    public["recipes/compare.py"] = Path(__file__).read_bytes()
    public["pins.json"] = (args.master.parent / "pins.json").read_bytes()
    public["README.md"] = (
        "# Phase 6 cache correction evidence\n\n"
        "Each group contains the original per-case JSON receipt and the log whose SHA-256 it records. "
        "Host metadata is limited to release-relevant fields. The original Phase 6 timings live in "
        "`benchmarks/aws_ecosystem_phase6/cpu_c7a_96vcpu/` in both published branches.\n\n"
        "From the extracted archive, regenerate the report with Python 3.11 or newer. Set "
        "`PHASE6_BASELINE` to the original receipt directory.\n\n"
        "```sh\npython recipes/compare.py --baseline \"$PHASE6_BASELINE\" --fast fast --master master "
        "--cloud machine.json --out regenerated\n```\n\n"
        "The benchmark drivers include their command-line options under `--help`. The original "
        "project and dependency revisions are in `pins.json`; each receipt records the compiler, command "
        "and input evidence for that measurement.\n").encode()
    if local.exists():
        public[local.name] = local.read_bytes()
        evidence["wsl_controls_sha256"] = sha(local)
    for group, directory in [("fast", args.fast), ("master", args.master),
                             *[(k, args.master.parent / k) for k in extra]]:
        if not directory.exists():
            continue
        for receipt in sorted(directory.glob("*.rerun.json")):
            data = read(receipt)
            public[f"{group}/{receipt.name}"] = receipt.read_bytes()
            if data.get("log_sha256"):
                log = directory / (data["case"] + (".log" if "profile_elaboration_ms" in data else ".build.log"))
                public[f"{group}/{log.name}"] = log.read_bytes()
        if (directory / "host.json").exists():
            raw_host = read(directory / "host.json")
            host = {k: raw_host[k] for k in ["commit","instance_type","cpu","mem_total_kb","cpu_affinity",
                                           "lean_version","lean_githash","sha256"] if k in raw_host}
            public[f"{group}/host.json"] = json.dumps(host, indent=2).encode()
    secrets = [machine.get(k) for k in ("accountId", "privateIp", "instanceId")]
    for group, root in [("fast", args.fast), ("master", args.master)]:
        uname = read(root / "host.json").get("uname")
        if uname:
            secrets.append(uname[1])
    private_data = re.compile(rb"(?:[A-Z]:[/\\]+Users[/\\][^/\\\s]+[/\\]|/(?:home|Users)/[\w.-]+/|"
                              rb"(?:AKIA|ASIA)[0-9A-Z]{16}|gh[pousr]_[\w]{25,}|github_pat_[\w]{30,}|"
                              rb"-----BEGIN [A-Z ]*PRIVATE KEY-----)", re.I)
    for name, content in public.items():
        if private_data.search(content) or any(secret and secret.encode() in content for secret in secrets):
            raise ValueError(f"Private machine identifier in publication file {name}")
    bundle(args.out / "evidence.zip", public)
    evidence["evidence_zip_sha256"] = sha(args.out / "evidence.zip")
    (args.out / "comparison.json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8", newline="\n")
    (args.out / "comparison.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
