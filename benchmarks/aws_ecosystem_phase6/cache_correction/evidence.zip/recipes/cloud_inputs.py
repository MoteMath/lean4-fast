"""Fetch the original benchmark sources and dependencies without timing setup work."""
import json
import os
import subprocess
from pathlib import Path

work = Path("/mnt/work")
manifest = json.loads((work / "fast/benchmarks/aws_ecosystem_phase5/cpu_c7a_96vcpu/repo_manifest.json").read_text())
inputs = {}
evidence = {}
for name in ("batteries", "qq", "aesop", "import_graph", "plausible", "doc_gen4", "cedar", "mathlib4"):
    entry = manifest[name + "_git"]
    raw = work / "corpora" / name
    raw.mkdir(exist_ok=True, parents=True)
    def run(cmd, cwd=raw):
        subprocess.run(cmd, cwd=cwd, check=True)
    if not (raw / ".git").exists():
        run(["git", "init"])
        run(["git", "remote", "add", "origin", entry["url"]])
    run(["git", "fetch", "--depth", "1", "origin", entry["commit"]])
    run(["git", "checkout", "--detach", entry["commit"]])
    project = raw / entry.get("subdir", ".")
    stock = Path.home() / ".elan/toolchains/leanprover--lean4---v4.35.0/bin/lake"
    os.environ["MATHLIB_NO_CACHE_ON_UPDATE"] = "1"
    run([str(stock), "env", "true"], cwd=project)
    description = ("Phase 6 wave_w_bench.driver.log records the fetched commit" if name != "cedar" else
                   "Phase 5 repo_manifest plus historical Git main at the Phase 6 run time")
    for alias in (("real_basic", "full_mathlib") if name == "mathlib4" else (name,)):
        inputs[alias] = str(project)
        evidence[alias] = {"baseline_revision": entry["commit"], "commit": entry["commit"],
                           "path": str(project), "url": entry["url"], "baseline_ref": entry["ref"],
                           "evidence": description}
for name, path in (("inputs.json", work), ("pins.json", work / "logs")):
    (path / name).write_text(json.dumps(inputs if name == "inputs.json" else evidence, indent=2) + "\n")
