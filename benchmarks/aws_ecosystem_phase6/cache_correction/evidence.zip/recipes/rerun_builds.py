#!/usr/bin/env python3
"""Replay archived Phase 6 compiler workloads on one pinned toolchain at a time."""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import subprocess
import sys
import tempfile


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def command(args, **kwargs):
    return subprocess.check_output(args, text=True, **kwargs).strip()


def rev(path):
    p = subprocess.run(["git", "-C", path, "rev-parse", "HEAD"], capture_output=True, text=True)
    return p.stdout.strip() if p.returncode == 0 else None


def modules(log):
    # Ignore native object, library and executable jobs.
    return collections.Counter(re.findall(r"\[\d+/\d+\] Built ([\w.']+)(?= \(|$)", log, re.M))


def recipe(receipt, bin_dir, source, project):
    argv = shlex.split(receipt["cmd"][-1].rsplit("; exec ", 1)[1])
    if Path(argv[0]).name == "lake":
        return [str(bin_dir / "lake"), *argv[1:]]
    assert Path(argv[0]).name == "lake_fast_build.sh"
    argv[0] = str(source / "aws-deploy/lake_fast_build.sh")
    argv[argv.index("--project") + 1] = str(project)
    argv[argv.index("--bin-dir") + 1] = str(bin_dir)
    return argv


def source_evidence(source, workload, pins):
    commit = rev(source)
    git = ["git", "-C", source]
    prefix = command([*git, "rev-parse", "--show-prefix"]).rstrip("/")
    tree = command([*git, "rev-parse", f"HEAD:{prefix}"])
    dirty = command([*git, "status", "--porcelain", "--", "."])
    manifest = source / "lake-manifest.json"
    manifest_hash = sha(manifest) if manifest.exists() else None
    evidence = dict(source_revision=commit, source_git_tree=tree, manifest_sha256=manifest_hash,
                    dirty_tracked_sources=bool(dirty), corpus_matches_baseline=None)
    fixture_trees = {"synthetic": "f2b6002b114f771f113545709cac891e25777a9f",
                     "downstream_bench": "b1c642f5f63e46089e04825fec4758e2ef29be7e"}
    if workload in fixture_trees:
        evidence["baseline_input_evidence"] = "Fixture tree in published Phase 6 commit 89a4e5ae92"
        evidence["corpus_matches_baseline"] = not dirty and tree == fixture_trees[workload]
        return evidence
    pin_name = "mathlib4" if workload in ("downstream_real", "real_basic", "full_mathlib") else workload
    pin = pins.get(workload) or pins.get(pin_name) or (pins.get("real_basic") if workload == "downstream_real" else {}) or {}
    expected = pin.get("baseline_revision") or pin.get("commit")
    if not expected:
        return evidence
    deps = []
    if manifest.exists():
        m = read(manifest)
        for dep in m.get("packages", []):
            if dep.get("type") == "git" and dep.get("rev"):
                dep_dir = source / m.get("packagesDir", ".lake/packages") / dep["name"]
                deps.append({"name": dep["name"], "expected": dep["rev"],
                             "actual": rev(dep_dir) if dep_dir.is_dir() else None})
    evidence.update(baseline_input_evidence=pin.get("evidence", "Recorded/reconstructed source pin"),
                    baseline_source_revision=expected, dependency_revisions=deps,
                    corpus_matches_baseline=not dirty and commit == expected
                    and (not pin.get("manifest_sha256") or pin["manifest_sha256"] == manifest_hash)
                    and all(d["expected"] == d["actual"] for d in deps))
    return evidence


def copy_project(source, dest, warm_dependencies=False):
    def ignore(directory, names):
        p = Path(directory)
        if p.name == ".lake" and (not warm_dependencies or p.parent == source):
            return {"build"}
        return set()
    # Preserve fetched repositories and their manifests, clean both package and dependency builds.
    if source.is_relative_to(dest) or dest.is_relative_to(source):
        raise ValueError("scratch and project input must be disjoint")
    shutil.copytree(source, dest, ignore=ignore)


def downstream_real(project, mathlib):
    pkg = project / "DownstreamReal"
    pkg.mkdir(parents=True)
    lake = project / ".lake"
    lake.mkdir()
    packages = mathlib / ".lake/packages"
    if packages.is_dir():
        (lake / "packages").symlink_to(packages, target_is_directory=True)
    (project / "lakefile.toml").write_text(
        'name = "downstream_real"\nversion = "0.1.0"\ndefaultTargets = ["DownstreamReal"]\n\n'
        '[[require]]\nname = "mathlib"\n' + f'path = "{mathlib}"\n\n'
        '[[lean_lib]]\nname = "DownstreamReal"\n')
    shutil.copy2(mathlib / "lean-toolchain", project / "lean-toolchain")
    imports = []
    for i in range(96):
        name = f"Mod{i:02d}"
        imports.append(f"public import DownstreamReal.{name}")
        (pkg / (name + ".lean")).write_text(
            f"module\npublic import Mathlib.Data.Real.Basic\n\nnamespace DownstreamReal.{name}\n\n"
            f"public def offset_{i} (x : Real) : Real := x + ({i + 1} : Real)\n\n"
            f"public theorem offset_{i}_comm (x y : Real) : x + y + ({i + 1} : Real) = "
            f"y + x + ({i + 1} : Real) := by\n  rw [add_comm x y]\n\nend DownstreamReal.{name}\n")
    (project / "DownstreamReal.lean").write_text(
        "module\n" + "\n".join(imports) + "\n\npublic def downstreamRealCount : Nat := 96\n")


def elapsed_ms(log):
    m = re.search(r"^\s*elaboration ([\d.]+)(ms|s)\s*$", log, re.M)
    return float(m[1]) * (1000 if m[2] == "s" else 1) if m else None


def profiles(args, proj, env, evidence):
    cases = sorted(args.baselines.glob("synthetic_profile_S*.log"))
    if args.con_gpu:
        cases.append(args.baselines / "synthetic_s5_bv_congpu.log")
    for case in cases:
        mode = case.stem
        mod = mode.split("synthetic_profile_")[-1] if "_profile_" in mode else "S5_BvDecideHardware"
        child = dict(env, LEAN_PATH=f"{proj}/.lake/build/lib/lean:{args.bin_dir.parent}/lib/lean")
        if mode == "synthetic_s5_bv_congpu":
            child.update(LEAN_BV_DECIDE_CON_GPU="1", CON_GPU_BIN=str(args.con_gpu))
        argv = [str(args.bin_dir / "lean"), "--profile", f"--root={proj}", str(proj / "SyntheticBench" / (mod + ".lean"))]
        log = args.output / (mode + ".log")
        with log.open("w") as stream:
            r = subprocess.run(argv, cwd=proj, env=child, stdout=stream, stderr=subprocess.STDOUT)
        timing = elapsed_ms(log.read_text(errors="replace"))
        write(args.output / (mode + ".rerun.json"), {
            "case": mode, "commit": args.commit, "workload": "synthetic", "command": argv,
            "status": "ok" if r.returncode == 0 and timing is not None else "failed",
            "exit_code": r.returncode, "profile_elaboration_ms": timing if r.returncode == 0 else None,
            "baseline_profile_elaboration_ms": elapsed_ms(case.read_text()), "baseline_sha256": sha(case),
            "log_sha256": sha(log), **evidence})


def run_case(args, path, inputs, env, retained, tmp):
    case = path.stem
    workload = case.split("_p6_")[0]
    old = read(path)
    baseline_modules = modules(path.with_suffix(".build.log").read_text(errors="replace"))
    result = dict(case=case, workload=workload, commit=args.commit, baseline_seconds=old["elapsed_sec"],
                  baseline_sha256=sha(path), baseline_built_modules=baseline_modules.total(),
                  elapsed_sec=None, status="failed", comparison_note="", module_set_matches_baseline=None,
                  corpus_matches_baseline=None)
    proj = tmp / case
    try:
        src = inputs.get(workload)
        if workload == "downstream_real":
            if "real_basic" not in retained:
                result["status"] = "missing-input"
                raise ValueError("requires successful real_basic_p6_cold in this invocation")
            downstream_real(proj, retained["real_basic"])
            evidence = source_evidence(Path(inputs["real_basic"]), workload, args.pins)
        elif src:
            source_path = Path(src).resolve(strict=True)
            evidence = source_evidence(source_path, workload, args.pins)
            warm = workload == "full_mathlib" and "zygote" in case
            if warm and workload not in retained:
                result["status"] = "missing-input"
                raise ValueError("requires successful full_mathlib_p6_cold in this invocation")
            copy_project(retained[workload] if warm else source_path, proj, warm)
        else:
            result["status"] = "missing-input"
            raise ValueError(f"no source path supplied for {workload}")
        result.update(evidence)
        assert not (proj / ".lake/build").exists(), "fresh project contains build outputs"
        argv = recipe(old, args.bin_dir, args.source, proj)
        result["command"] = argv
        log = args.output / (case + ".build.log")
        metric = args.output / (case + ".measurement.json")
        r = subprocess.run([sys.executable, args.source / "benchmarks/measure_linux_bench.py",
                            "--workdir", proj, "--json-out", metric, "--", "bash", "-c",
                            'exec "$@" >"$0" 2>&1', log, *argv], env=env, stdout=subprocess.DEVNULL)
        metrics = read(metric)
        output = log.read_text(errors="replace")
        actual = modules(output)
        root_oleans = list((proj / ".lake/build/lib/lean").rglob("*.olean"))
        missing = sorted((baseline_modules - actual).elements())
        added = sorted((actual - baseline_modules).elements())
        result.update(metrics=metrics, log_sha256=sha(log), built_modules=actual.total(),
                      module_set_matches_baseline=actual == baseline_modules,
                      baseline_modules_missing=len(missing), new_modules_added=len(added),
                      baseline_modules_missing_sample=missing[:12], new_modules_added_sample=added[:12],
                      root_oleans=len(root_oleans))
        if "zygote" in case:
            stats = re.findall(r"shutdown stats snapshot_hits=(\d+) clean_cow_hits=(\d+) fallbacks=(\d+)", output)
            result["zygote_stats"] = dict(zip(["snapshot_hits","clean_cow_hits","fallbacks"], map(int, stats[-1]))) if stats else None
        if r.returncode or metrics["exit_code"]:
            result["comparison_note"] = "Build failed; see build log."
        elif not actual or not root_oleans:
            result.update(status="no-op", comparison_note="No newly compiled root Lean module evidence.")
        elif "zygote" in case and not result["zygote_stats"]:
            result["comparison_note"] = "Missing zygote shutdown statistics; build mode unconfirmed."
        else:
            result.update(status="ok", elapsed_sec=metrics["elapsed_sec"])
            if missing or added:
                result["comparison_note"] = "Compiled module set differs from the archived log."
            if case in ("real_basic_p6_cold", "full_mathlib_p6_cold"):
                retained[workload] = proj
            if case == "synthetic_p6_cold_j48":
                profiles(args, proj, env, evidence)
    except (OSError, ValueError, subprocess.SubprocessError, AssertionError) as exc:
        result["comparison_note"] = str(exc)
    finally:
        write(args.output / (case + ".rerun.json"), result)
        if proj.is_dir() and proj not in retained.values():
            shutil.rmtree(proj)
    print(case, result["status"], result["elapsed_sec"], flush=True)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for arg in ("source", "bin-dir", "inputs", "work", "output"):
        p.add_argument("--" + arg, type=lambda x: Path(x).resolve(), required=True)
    p.add_argument("--baselines", type=lambda x: Path(x).resolve())
    p.add_argument("--commit", required=True)
    p.add_argument("--con-gpu", type=lambda x: Path(x).resolve())
    p.add_argument("--corpus-evidence", type=lambda x: Path(x).resolve())
    p.add_argument("--cases", nargs="+", help="exact archive stems; full_zygote and downstream_real need their prerequisite cold rows")
    args = p.parse_args()
    args.baselines = args.baselines or args.source / "benchmarks/aws_ecosystem_phase6/cpu_c7a_96vcpu"
    args.output.mkdir(parents=True, exist_ok=True)
    if any(args.output.glob("*.rerun.json")):
        p.error("use an empty output directory for a new run")
    args.work.mkdir(parents=True, exist_ok=True)
    actual = rev(args.source)
    if actual != args.commit:
        p.error(f"source checkout {actual} does not match requested commit {args.commit}")
    env = os.environ.copy()
    for key in ("ELAN_TOOLCHAIN", "LEAN_NUM_THREADS", "LAKE_CHILD_LEAN_THREADS",
                "LEAN_PATH", "LEAN_SYSROOT", "LEAN_BV_DECIDE_CON_GPU", "CON_GPU_BIN", "LAKE_JOBS"):
        env.pop(key, None)
    env["PATH"] = str(args.bin_dir) + ":" + ":".join(x for x in env["PATH"].split(":") if not x.rstrip("/").endswith(".elan/bin"))
    inputs = read(args.inputs)
    args.pins = read(args.corpus_evidence) if args.corpus_evidence else {}
    inputs.setdefault("synthetic", str(args.source / "benchmarks/ecosystem_bench/synthetic"))
    inputs.setdefault("downstream_bench", str(args.source / "benchmarks/downstream_bench"))
    product = Path("/sys/class/dmi/id/product_name")
    host = {"commit": actual, "instance_type": product.read_text().strip() if product.is_file() else None,
            "uname": list(platform.uname()), "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "cpu": command(["lscpu", "-J"]), "mem_total_kb": int(re.search(r"MemTotal:\s+(\d+)", Path("/proc/meminfo").read_text())[1]),
            "lean_version": command([args.bin_dir / "lean", "--version"], env=env),
            "lean_githash": command([args.bin_dir / "lean", "--githash"], env=env),
            "sha256": {str(path): sha(path) for path in [args.bin_dir / "lean", args.bin_dir / "lake",
                        args.bin_dir / "lean-zygote", args.bin_dir.parent / "lib/lean/libleanshared.so"] if path.is_file()}}
    write(args.output / "host.json", host)
    if host["lean_githash"] != actual:
        p.error(f"lean --githash reports {host['lean_githash']}, expected {actual}")
    rows = {f.stem:f for f in args.baselines.glob("*_p6_*.json")}
    case_order = sorted(rows, key=lambda k: (0 if k == "real_basic_p6_cold" else 2 if k.startswith("downstream_real_") else 1, k))
    if args.cases:
        unknown = set(args.cases).difference(rows)
        if unknown:
            p.error(f"unknown archived cases: {sorted(unknown)}")
        case_order = [k for k in case_order if k in args.cases]
    with tempfile.TemporaryDirectory(prefix="wave-w-", dir=args.work) as temp:
        retained = {}
        summary = []
        for case in case_order:
            summary.append(run_case(args, rows[case], inputs, env, retained, Path(temp)))
            write(args.output / "summary.json", summary)
    return int(any(row["status"] != "ok" for row in summary))


if __name__ == "__main__":
    sys.exit(main())
