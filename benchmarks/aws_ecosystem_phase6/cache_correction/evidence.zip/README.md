# Phase 6 cache correction evidence

Each group contains the original per-case JSON receipt and the log whose SHA-256 it records. Host metadata is limited to release-relevant fields. The original Phase 6 timings live in `benchmarks/aws_ecosystem_phase6/cpu_c7a_96vcpu/` in both published branches.

From the extracted archive, regenerate the report with Python 3.11 or newer. Set `PHASE6_BASELINE` to the original receipt directory.

```sh
python recipes/compare.py --baseline "$PHASE6_BASELINE" --fast fast --master master --cloud machine.json --out regenerated
```

The benchmark drivers include their command-line options under `--help`. The original project and dependency revisions are in `pins.json`; each receipt records the compiler, command and input evidence for that measurement.
